const markerIcons = {
    food: "../iconsMarkers/restaurant.svg",
    gas_station: "../iconsMarkers/gas_station.svg",
    repair: "../iconsMarkers/repair.svg",
    hotel: "../iconsMarkers/hotel.svg",
    hospital: "../iconsMarkers/hospital.svg",
    tourist_spots: "../iconsMarkers/tourist_spots.svg"
}